﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Gestor_de_Productos_WTF
{
    /// <summary>
    /// Lógica de interacción para Window1.xaml
    /// </summary>
    public partial class Window1 : Window
        
    {
        public Producto Producto { get; set; }
        public Window1()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, RoutedEventArgs e) 
        {
            Producto = new Producto
            {
                Id = int.Parse(txtId.Text),
                CodigoBarras = txtCodigoBarras.Text,
                Nombre = txtNombre.Text,
                Precio = (double)decimal.Parse(txtPrecio.Text),
                Stock = int.Parse(txtStock.Text),
            };
            this.DialogResult = true;
            this.Close();
        }
    }
    
}
